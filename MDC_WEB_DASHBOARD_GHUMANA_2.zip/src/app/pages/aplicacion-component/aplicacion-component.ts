import { Component, OnInit, OnDestroy } from "@angular/core";
import { Router } from "@angular/router";
import swal from "sweetalert2";
import { environment } from "src/environments/environment";
import { FormBuilder, Validators } from "@angular/forms";
import { Functions } from "src/app/utils/functions";
import { ActivatedRoute } from "@angular/router";
import { ListasService } from "src/app/services/listas.service";
import { AuthService } from "src/app/services/auth.service";
import { IUsuario } from "src/app/interfaces/i-usuario";

@Component({
  selector: "app-aplicacion-component",
  templateUrl: "./aplicacion-component.html",
  styleUrls: ["./aplicaciones.component.styl"],
})
export class AplicacionComponent implements OnInit, OnDestroy {
  data_usuario: IUsuario;
  lista_aplicaciones: any[] = [];
  protocol: string = location.protocol;
  token: any = null;
  constructor(
    private listasService: ListasService,
    private authService: AuthService
  ) {
    this.data_usuario = this.authService.getDataLogin();
  }
  ngOnInit() {
    this.listasService.getListaAplicaciones().subscribe((response) => {
      this.lista_aplicaciones = response.data;
    });
  }
  ngOnDestroy() {}

  redireccionar(url_aplicacion, url_login_app) {
    let data_form = {
      username: "erika.restrepo@madecentro.co",
      password: "1",
      url_login_app: url_login_app,
      url_aplicacion: url_aplicacion,
    };

    this.listasService.inicioSesionApps(data_form).subscribe((response) => {
      let data = JSON.stringify(response.data);
      this.token = btoa(data);
      window.open(
        `http://172.16.2.6/${url_aplicacion}/?token=${this.token}`,
        "_blank"
      );
    });
  }
}
