export const environment = {
  production: true,
  URL_SERVE_REGISTRO: "https://app.madecentro.com/mercadeo/tc-carpintero/",
  URL_SERVE: "https://app.madecentro.com/mercadeo/admin-carpintero/",
  URL_SERVE_ADMIN: "https://app.madecentro.com/mercadeo/admin-carpintero/",
  URL_API: "https://app.madecentro.com/APIS/WebApiNode_TUCARPINTERO/",
  TOKEN_NAME: "GHbFU9xZgXqBwAdcf5pwXHA3tcf23PUzGsK7rcny",
  URL_ARCHIVOS: "https://app.madecentro.com/",
  URL_ARCHIVOS_S3: "https://s3-sa-east-1.amazonaws.com/",
  TAMANIO_MAXIMO_CARGA_ADJUNTO_KB: 2000,
};
