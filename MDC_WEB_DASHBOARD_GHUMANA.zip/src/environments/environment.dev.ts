export const environment = {
  production: false,
  URL_SERVE: "http://localhost:4200/",
  URL_SERVE_REGISTRO: "http://172.16.2.6/mercadeo/tc-carpintero/",
  URL_SERVE_ADMIN: "http://172.16.2.6/mercadeo/admin-carpintero/",
  URL_API: "http://localhost:1600/",
  TOKEN_NAME: "GHbFU9xZgXqBwAdcf5pwXHA3tcf23PUzGsK7rcny",
  URL_ARCHIVOS: "http://172.16.2.6/",
  URL_ARCHIVOS_S3: "https://s3-sa-east-1.amazonaws.com/",
  TAMANIO_MAXIMO_CARGA_ADJUNTO_KB: 2000,
};
